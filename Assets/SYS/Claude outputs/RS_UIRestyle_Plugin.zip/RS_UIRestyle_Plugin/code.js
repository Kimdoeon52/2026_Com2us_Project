// RE:AL STEEL — Modern Mystic UI Kit 마무리 스크립트
// 1) 미니맵 → 전술 레이더  2) 크로스헤어 → 조준선  3) 일러스트 → 원화 자리표시  4) 프리빌드 문구 교체
const report = [];
const V = id => figma.variables.getVariableByIdAsync(id);
const toHex = c => '#' + [c.r, c.g, c.b].map(v => Math.round(v * 255).toString(16).padStart(2, '0')).join('').toUpperCase();

async function main() {
  const vars = {
    bg: await V('VariableID:2:322'), tint5: await V('VariableID:4:289'), tint10: await V('VariableID:2:323'),
    line: await V('VariableID:2:325'), dim: await V('VariableID:4:293'), hot: await V('VariableID:2:330'),
    primary: await V('VariableID:2:326'), secondary: await V('VariableID:2:327'), grey: await V('VariableID:4:286'),
    text: await V('VariableID:2:324'),
  };
  const bindPaint = (p, v) => figma.variables.setBoundVariableForPaint(p, 'color', v);
  const KEY = { '#101010': 'bg', '#202020': 'tint5', '#C0C0C0': 'line', '#404040': 'dim', '#FF0000': 'hot', '#FFFF00': 'ACC' };
  function bindAll(root, acc) {
    for (const n of [root, ...root.findAll(() => true)]) {
      for (const prop of ['fills', 'strokes']) {
        if (!(prop in n) || !Array.isArray(n[prop]) || !n[prop].length) continue;
        n[prop] = n[prop].map(p => {
          if (p.type !== 'SOLID') return p;
          const r = KEY[toHex(p.color)];
          return r ? bindPaint(p, r === 'ACC' ? acc : vars[r]) : p;
        });
      }
    }
  }

  // ---------- 1. 미니맵 (265x234)
  const W = 265, H = 234, c = 18, cx = 132, cy = 120;
  let grid = '';
  for (let x = 20; x < W; x += 24) grid += `<line x1="${x}" y1="6" x2="${x}" y2="${H - 6}" stroke="#404040" stroke-width="1"/>`;
  for (let y = 18; y < H; y += 24) grid += `<line x1="6" y1="${y}" x2="${W - 6}" y2="${y}" stroke="#404040" stroke-width="1"/>`;
  let ticks = '';
  for (let k = 0; k < 12; k++) ticks += `<rect x="${40 + k * 15}" y="${H - 12}" width="1" height="${k % 4 === 0 ? 6 : 3}" fill="#C0C0C0"/>`;
  const frame = `${c},0 ${W},0 ${W},${H - c} ${W - c},${H} 0,${H} 0,${c}`;
  const mmSvg = `<svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" fill="none" xmlns="http://www.w3.org/2000/svg">
<polygon points="${frame}" fill="#101010" fill-opacity="0.92"/>${grid}
<circle cx="${cx}" cy="${cy}" r="88" stroke="#C0C0C0" stroke-opacity="0.5" stroke-width="1"/>
<circle cx="${cx}" cy="${cy}" r="58" stroke="#C0C0C0" stroke-opacity="0.5" stroke-width="1" stroke-dasharray="3 4"/>
<circle cx="${cx}" cy="${cy}" r="28" stroke="#C0C0C0" stroke-opacity="0.5" stroke-width="1"/>
<path d="M${cx} ${cy} L${cx} ${cy - 88} A88 88 0 0 1 ${cx + 76.2} ${cy - 44} Z" fill="#FFFF00" fill-opacity="0.14"/>
<line x1="${cx}" y1="${cy}" x2="${cx}" y2="${cy - 88}" stroke="#FFFF00" stroke-width="1.5"/>
<polygon points="${cx},${cy - 9} ${cx + 7},${cy + 7} ${cx},${cy + 3} ${cx - 7},${cy + 7}" fill="#FFFF00"/>
<rect x="${cx + 42}" y="${cy - 30}" width="7" height="7" fill="#FF0000"/>
<rect x="${cx - 60}" y="${cy + 22}" width="7" height="7" fill="#FF0000"/>
<rect x="${cx + 20}" y="${cy + 52}" width="5" height="5" fill="#C0C0C0"/>
<polygon points="${frame}" stroke="#C0C0C0" stroke-width="1.5"/>
<rect x="0" y="${c + 6}" width="3" height="40" fill="#FFFF00"/>
<rect x="${c + 8}" y="0" width="46" height="4" fill="#FFFF00"/>
<rect x="${W - 60}" y="6" width="50" height="2" fill="#C0C0C0"/><rect x="${W - 40}" y="11" width="30" height="2" fill="#C0C0C0"/>${ticks}</svg>`;

  // ---------- 2. 조준선 (200x151)
  const X = 100, Y = 76;
  const seg = (a0, a1, r) => {
    const p = a => [X + r * Math.cos(a * Math.PI / 180), Y + r * Math.sin(a * Math.PI / 180)];
    const [x0, y0] = p(a0), [x1, y1] = p(a1);
    return `M${x0.toFixed(2)} ${y0.toFixed(2)} A${r} ${r} 0 0 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
  };
  let arcs = '';
  for (const a of [-80, 10, 100, 190]) arcs += `<path d="${seg(a, a + 60, 70)}" stroke="#FFFF00" stroke-width="2"/>`;
  for (const a of [-35, 55, 145, 235]) arcs += `<path d="${seg(a, a + 70, 52)}" stroke="#C0C0C0" stroke-opacity="0.7" stroke-width="1"/>`;
  const reSvg = `<svg width="200" height="151" viewBox="0 0 200 151" fill="none" xmlns="http://www.w3.org/2000/svg">${arcs}
<path d="M${X - 26} ${Y - 14} V${Y - 26} H${X - 14} M${X + 14} ${Y - 26} H${X + 26} V${Y - 14} M${X + 26} ${Y + 14} V${Y + 26} H${X + 14} M${X - 14} ${Y + 26} H${X - 26} V${Y + 14}" stroke="#FFFF00" stroke-width="2"/>
<line x1="${X}" y1="${Y - 74}" x2="${X}" y2="${Y - 60}" stroke="#C0C0C0" stroke-width="1.5"/><line x1="${X}" y1="${Y + 60}" x2="${X}" y2="${Y + 74}" stroke="#C0C0C0" stroke-width="1.5"/>
<line x1="${X - 74}" y1="${Y}" x2="${X - 60}" y2="${Y}" stroke="#C0C0C0" stroke-width="1.5"/><line x1="${X + 60}" y1="${Y}" x2="${X + 74}" y2="${Y}" stroke="#C0C0C0" stroke-width="1.5"/>
<line x1="${X - 10}" y1="${Y}" x2="${X - 4}" y2="${Y}" stroke="#FFFF00" stroke-width="1.5"/><line x1="${X + 4}" y1="${Y}" x2="${X + 10}" y2="${Y}" stroke="#FFFF00" stroke-width="1.5"/>
<rect x="${X - 1.5}" y="${Y - 1.5}" width="3" height="3" fill="#FFFF00"/>
<rect x="${X + 30}" y="${Y - 40}" width="22" height="2" fill="#C0C0C0"/><rect x="${X + 30}" y="${Y - 35}" width="14" height="2" fill="#C0C0C0"/></svg>`;

  for (const [setId, svg, name] of [['28:1373', mmSvg, 'radar'], ['29:1696', reSvg, 'reticle']]) {
    try {
      const set = await figma.getNodeByIdAsync(setId);
      if (!set) { report.push(`${name}: 세트 없음`); continue; }
      set.children.forEach((comp, i) => {
        for (const k of [...comp.children]) k.remove();
        const fr = figma.createNodeFromSvg(svg);
        fr.name = name; fr.fills = []; fr.clipsContent = false;
        comp.appendChild(fr); fr.x = 0; fr.y = 0;
        bindAll(fr, i === 0 ? vars.primary : vars.secondary);
        fr.constraints = { horizontal: 'SCALE', vertical: 'SCALE' };
      });
      report.push(`${name}: ${set.children.length}개 변형 교체`);
    } catch (e) { report.push(`${name} 실패: ${e}`); }
  }

  // ---------- 3. 일러스트 → 원화 자리표시
  await figma.loadFontAsync({ family: 'Barlow Condensed', style: 'Bold' });
  const page = figma.currentPage;
  const skipRoots = new Set(['Import .fig file into Figma', 'Update color variables', 'Export your Component', 'Pick component version', 'thumbnail', 'Digital Product License']);
  const rootOf = n => { let p = n; while (p.parent && p.parent.type !== 'PAGE') p = p.parent; return p; };
  const LABEL = { backillustration: 'STAGE VIEW  ·  3D 스테이지', Character_Female: 'CHARACTER ART', Character_Male: 'CHARACTER ART', Gamer_Streamer: 'CASTER ART', Spells: 'PART ICON' };
  let ph = 0, hidden = 0;
  const imgNodes = page.findAll(n => 'fills' in n && Array.isArray(n.fills) && n.fills.some(f => f.type === 'IMAGE'));
  for (const n of imgNodes) {
    if (skipRoots.has(rootOf(n).name)) continue;
    try {
      if (n.name === 'Hand_Perspective') { n.visible = false; hidden++; continue; }
      n.fills = [bindPaint({ type: 'SOLID', color: { r: 0, g: 0, b: 0 } }, vars.tint10)];
      n.strokes = [bindPaint({ type: 'SOLID', color: { r: 0, g: 0, b: 0 } }, vars.grey)];
      n.strokeWeight = 1; n.dashPattern = [4, 4];
      if (n.parent && n.parent.type === 'FRAME' && 'cornerRadius' in n.parent && typeof n.parent.cornerRadius === 'number' && n.parent.cornerRadius > 0) n.parent.cornerRadius = 0;
      const par = n.parent;
      const canLabel = par && par.type !== 'INSTANCE' && !(par.layoutMode && par.layoutMode !== 'NONE');
      if (canLabel) {
        const t = figma.createText();
        t.fontName = { family: 'Barlow Condensed', style: 'Bold' };
        t.characters = LABEL[n.name] || 'ART';
        t.fontSize = Math.max(10, Math.min(18, n.width / 10));
        t.letterSpacing = { unit: 'PERCENT', value: 12 };
        t.fills = [bindPaint({ type: 'SOLID', color: { r: 1, g: 1, b: 1 } }, vars.grey)];
        const idx = par.children.indexOf(n);
        par.insertChild(idx + 1, t);
        t.x = n.x + 10; t.y = n.y + 10;
        t.name = 'artLabel';
      }
      ph++;
    } catch (e) { report.push(`이미지 ${n.name} 실패: ${e}`); }
  }
  report.push(`원화 자리표시 ${ph}개, 손 이미지 숨김 ${hidden}개`);

  // ---------- 4. 프리빌드 문구 교체 (정확히 일치하는 문구만)
  const REPL = {
    'Death Potion': 'HEAD UNIT', 'Cloud Potion': 'ARM UNIT', 'Lava Potion': 'CORE UNIT',
    'Attack': 'ATK', 'Defense': 'DEF', 'Speed': 'SPD', 'Stealth': 'PWR', 'EX PTS': 'SYNC RATE',
    'Planet Vortrexia': 'GUILD RACE  ·  ROUND 03', 'Sir Aric': 'MECHANIC', 'Valen': 'RIVAL',
    'Account Creation': 'PILOT REGISTRATION', 'Analytics': 'UNIT ANALYSIS', 'Databases': 'PARTS DB',
  };
  let replaced = 0;
  const prebuilds = page.children.filter(n => /^prebuild0[1-6]$/.test(n.name));
  for (const pb of prebuilds) {
    for (const t of pb.findAllWithCriteria({ types: ['TEXT'] })) {
      const key = t.characters.trim();
      if (!(key in REPL)) continue;
      try {
        for (const s of t.getStyledTextSegments(['fontName'])) await figma.loadFontAsync(s.fontName);
        t.characters = REPL[key]; replaced++;
      } catch (e) { report.push(`문구 ${key} 실패: ${e}`); }
    }
  }
  report.push(`문구 교체 ${replaced}개`);
}

main()
  .then(() => figma.closePlugin('완료 — ' + report.join(' / ')))
  .catch(e => figma.closePlugin('오류: ' + e + ' / ' + report.join(' / ')));
